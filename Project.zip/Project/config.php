<?php
   $dbhost = 'localhost';
   $dbuser = 'root';
   $dbpass = 'pratikwagh1995';
   
   $conn = mysql_connect($dbhost, $dbuser, $dbpass);
?>
